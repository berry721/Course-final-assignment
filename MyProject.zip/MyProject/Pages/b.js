var colors = [
    {
        c1: '#00c7ef',
        c2: '#0AF3FF',
    },
    {
        c1: '#FF8E14',
        c2: '#FFA12F',
    },
    {
        c1: '#AF5AFF',
        c2: '#B62AFF',
    },
    {
        c1: '#25dd59',
        c2: '#29f463',
    },
    {
        c1: '#6E35FF',
        c2: '#6E67FF',
    },
    {
        c1: '#002AFF',
        c2: '#0048FF',
    },
    {
        c1: '#8CD282',
        c2: '#95F300',
    },
    {
        c1: '#3B0EFF',
        c2: '#604BFF',
    },
    {
        c1: '#00BE74',
        c2: '#04FDB8',
    },
    {
        c1: '#4a3ac6',
        c2: '#604BFF',
    },
];

function getData() {
    let data = {
        name: 'Computer Science and Technology',
        value: 0,
        list: [],
    };

    let obj1={name:'Theoretical basis of Computer Science', value:1,list:[]};
    let obj11 = {name: 'Discrete Mathematics',value: 1 + '-'+1 + '-'  + 1};
    obj11.list=[];
    obj1.list.push(obj11);
    let obj12 = {name: 'Computational Theory',value: 1 + '-'+1 + '-'  + 2};
    obj12.list=[];
    obj1.list.push(obj12);
    let obj13 = {name: 'Numerical Computation',value: 1 + '-'+1 + '-'  + 3};
    obj13.list=[];
    obj1.list.push(obj13);
    let obj14 = {name: 'Program Theory',value: 1 + '-'+1 + '-'  + 4};
    obj14.list=[];
    obj1.list.push(obj14);
    let obj15 = {name: 'Operations Research',value: 1 + '-'+1 + '-'  + 5};
    obj15.list=[];
    obj1.list.push(obj15);
    data.list.push(obj1);

    let obj2={name:'Users and Organizations', value:2,list:[]};
    let obj21 = {name: 'Social Issues and Professional Practice',value: 1 + '-'+2 + '-'  + 1};
    obj21.list=[];
    obj2.list.push(obj21);
    let obj22 = {name: 'Security Policy and Management',value: 1 + '-'+2 + '-'  + 2};
    obj22.list=[];
    obj2.list.push(obj22);
    let obj23 = {name: 'IS Management and Leadership',value: 1 + '-'+2 + '-'  + 3};
    obj23.list=[];
    obj2.list.push(obj23);
    let obj24 = {name: 'Enterprise and Architecture',value: 1 + '-'+2 + '-'  + 4};
    obj24.list=[];
    obj2.list.push(obj24);
    let obj25 = {name: 'Project Management',value: 1 + '-'+2 + '-'  + 5};
    obj25.list=[];
    obj2.list.push(obj25);
    let obj26 = {name: 'User Experience Design',value: 1 + '-'+2 + '-'  + 6};
    obj26.list=[];
    obj2.list.push(obj26);
    data.list.push(obj2);

    let obj3={name:'Systems Modeling', value:2,list:[]};
    let obj31 = {name: 'Security Issues and Principles',value: 1 + '-'+3 + '-'  + 1};
    obj31.list=[];
    obj3.list.push(obj31);
    let obj32 = {name: 'Systems Analysis & Design',value: 1 + '-'+3 + '-'  + 2};
    obj32.list=[];
    obj3.list.push(obj32);
    let obj33 = {name: 'Requirements Analysis and Specifications',value: 1 + '-'+3 + '-'  + 3};
    obj33.list=[];
    obj3.list.push(obj33);
    let obj34 = {name: 'Data and Information Management',value: 1 + '-'+3 + '-'  + 4};
    obj34.list=[];
    obj3.list.push(obj34);
    data.list.push(obj3);

    let obj4={name:'Systems Architecture and Infrastructure', value:4,list:[]};
    let obj41 = {name: 'Virtual Systems and Services',value: 1 + '-'+4 + '-'  + 1};
    obj41.list=[];
    obj4.list.push(obj41);
    let obj42 = {name: 'Intelligent Systems (AI) ',value: 1 + '-'+4 + '-'  + 2};
    obj42.list=[];
    obj4.list.push(obj42);
    let obj43 = {name: 'Internet of Things',value: 1 + '-'+4 + '-'  + 3};
    obj43.list=[];
    obj4.list.push(obj43);
    let obj44 = {name: 'Parallel and Distributed Computing',value: 1 + '-'+4 + '-'  + 4};
    obj44.list=[];
    obj4.list.push(obj44);
    let obj45 = {name: 'Computer Networks',value: 1 + '-'+4 + '-'  + 5};
    obj45.list=[];
    obj4.list.push(obj45);
    let obj46 = {name: 'Embedded Systems',value: 1 + '-'+4 + '-'  + 6};
    obj46.list=[];
    obj4.list.push(obj46);
    let obj47 = {name: 'Integrated Systems Technology',value: 1 + '-'+4 + '-'  + 7};
    obj47.list=[];
    obj4.list.push(obj47);
    let obj48 = {name: 'Platform Technologies',value: 1 + '-'+4 + '-'  + 8};
    obj48.list=[];
    obj4.list.push(obj48);
    let obj49 = {name: 'Security Technology and Implementation',value: 1 + '-'+4 + '-'  + 9};
    obj49.list=[];
    obj4.list.push(obj49);
    data.list.push(obj4);

    let obj5={name:'Software Development', value:5,list:[]};
    let obj51 = {name: 'Software Quality, Verification and Validation',value: 1 + '-'+5 + '-'  + 1};
    obj51.list=[];
    obj5.list.push(obj51);
    let obj52 = {name: 'Software Process',value: 1 + '-'+5 + '-'  + 2};
    obj52.list=[];
    obj5.list.push(obj52);
    let obj53 = {name: 'Software Modeling and Analysis',value: 1 + '-'+5 + '-'  + 3};
    obj53.list=[];
    obj5.list.push(obj53);
    let obj54 = {name: 'Software Design',value: 1 + '-'+5 + '-'  + 4};
    obj54.list=[];
    obj5.list.push(obj54);
    let obj55 = {name: 'Platform-Based Development',value: 1 + '-'+5 + '-'  + 5};
    obj55.list=[];
    obj5.list.push(obj55);
    data.list.push(obj5);

    let obj6={name:'Software Fundamentals', value:6,list:[]};
    let obj61 = {name: 'Graphics and Visualization',value: 1 + '-'+6 + '-'  + 1};
    obj61.list=[];
    obj6.list.push(obj61);
    let obj62 = {name: 'Operating Systems ',value: 1 + '-'+6 + '-'  + 2};
    obj62.list=[];
    obj6.list.push(obj62);
    let obj63 = {name: 'Data Structures,Algorithms and Complexity',value: 1 + '-'+6 + '-'  + 3};
    obj63.list=[];
    obj6.list.push(obj63);
    let obj64 = {name: 'Programming Languages',value: 1 + '-'+6 + '-'  + 4};
    obj64.list=[];
    obj6.list.push(obj64);
    let obj65 = {name: 'Programming Fundamentals',value: 1 + '-'+6 + '-'  + 5};
    obj65.list=[];
    obj6.list.push(obj65);
    let obj66 = {name: 'Computing Systems Fundamentals',value: 1 + '-'+6+ '-'  + 6};
    obj66.list=[];
    obj6.list.push(obj66);
    data.list.push(obj6);

    let obj7={name:'Hardware', value:7,list:[]};
    let obj71 = {name: 'Architecture and Organization',value: 1 + '-'+7 + '-'  + 1};
    obj71.list=[];
    obj7.list.push(obj71);
    let obj72 = {name: 'Digital Design',value: 1 + '-'+7 + '-'  + 2};
    obj72.list=[];
    obj7.list.push(obj72);
    let obj73 = {name: 'Circuits and Electronics',value: 1 + '-'+7 + '-'  + 3};
    obj73.list=[];
    obj7.list.push(obj73);
    let obj74 = {name: 'Signal Processing',value: 1 + '-'+7 + '-'  + 4};
    obj74.list=[];
    obj7.list.push(obj74);
    data.list.push(obj7);

    var arr = [];
    arr.push(data);
    //   arr=handle(arr,0)
    return arr;
}

var listData = getData();
var list = [];
var links = [];
var legend = [];

var categories = listData[0].list.map((item) => {
    return {
        name: item.name,
    };
});

var legendColor = colors.map((item) => item.c2);

handle2(JSON.parse(JSON.stringify(listData)), 0);
handle3(JSON.parse(JSON.stringify(listData)), 0);

//计算list
function handle2(arr, idx, color, category) {
    arr.forEach((item, index) => {
        if (item.name === null) {
            return false;
        }
        // 设置节点大小
        let symbolSize = 10;
        switch (idx) {
            case 0:
                symbolSize = 70;
                break;
            case 1:
                symbolSize = 50;
                break;
            default:
                symbolSize = 10;
                break;
        }

        // 每个节点所对应的文本标签的样式。
        let label = null;
        switch (idx) {
            case 0:
            case 1:
                label = {
                    position: 'inside',
                    rotate: 0,
                };
                break;
            default:
                break;
        }

        //计算出颜色,从第二级开始
        if (idx === 0) {
            color = colors[0];
        }
        if (idx == 1) {
            color = colors.find((itemm, eq) => eq == index % 10);
            legend.push(item.name);
        }
        // 设置线条颜色
        let lineStyle = {
            color: color.c2,
        };
        // 设置节点样式
        let bgcolor = null;
        if (idx === 0) {
            bgcolor = {
                type: 'radial',
                x: 0.5,
                y: 0.5,
                r: 0.5,
                colorStops: [
                    {
                        offset: 0,
                        color: color.c1, // 0% 处的颜色
                    },
                    {
                        offset: 0.8,
                        color: color.c1, // 80% 处的颜色
                    },
                    {
                        offset: 1,
                        color: 'rgba(0, 0, 0, 0.3)', // 100% 处的颜色
                    },
                ],
                global: false,
            };
        } else {
            bgcolor = {
                type: 'radial',
                x: 0.5,
                y: 0.5,
                r: 0.5,
                colorStops: [
                    {
                        offset: 0,
                        color: color.c1, // 0% 处的颜色
                    },
                    {
                        offset: 0.4,
                        color: color.c1, // 0% 处的颜色
                    },
                    {
                        offset: 1,
                        color: color.c2, // 100% 处的颜色
                    },
                ],
                global: false,
            };
        }
        let itemStyle = null;
        if (item.list && item.list.length !== 0) {
            //非子节点
            itemStyle = {
                borderColor: color.c2,
                color: bgcolor,
            };
        } else {
            //子节点
            item.isEnd = true;
            if (item.isdisease == 'true') {
                itemStyle = {
                    color: color.c2,
                    borderColor: color.c2,
                };
            } else {
                itemStyle = {
                    color: 'transparent',
                    borderColor: color.c2,
                };
            }
        }
        //可以改变来实现节点发光效果，但体验不好
        itemStyle = Object.assign(itemStyle, {
            shadowColor: 'rgba(255, 255, 255, 0.5)',
            shadowBlur: 10,
        });

        if (idx == 1) {
            category = item.name;
        }
        let obj = {
            name: item.name,
            symbolSize: symbolSize,
            category: category,
            label,
            color: bgcolor,
            itemStyle,
            lineStyle,
        };
        obj = Object.assign(item, obj);
        if (idx === 0) {
            obj = Object.assign(obj, {
                root: true,
            });
        }
        if (item.list && item.list.length === 0) {
            obj = Object.assign(obj, {
                isEnd: true,
            });
        }
        list.push(obj);
        if (item.list && item.list.length > 0) {
            handle2(item.list, idx + 1, color, category);
        }
    });
}
// 计算links
function handle3(arr, index, color) {
    arr.forEach((item) => {
        if (item.list) {
            item.list.forEach((item2, eq) => {
                if (index === 0) {
                    color = colors.find((itemm, eq2) => eq2 == eq % 10);
                }
                let lineStyle = null;
                switch (index) {
                    case 0:
                        if (item2.list.length > 0) {
                            lineStyle = {
                                normal: {
                                    color: 'target',
                                },
                            };
                        } else {
                            lineStyle = {
                                normal: {
                                    color: color.c2,
                                },
                            };
                        }
                        break;
                    default:
                        lineStyle = {
                            normal: {
                                color: 'source',
                            },
                        };
                        break;
                }
                let obj = {
                    source: item.name,
                    target: item2.name,
                    lineStyle,
                };
                links.push(obj);
                if (item2.list && item.list.length > 0) {
                    handle3(item.list, index + 1);
                }
            });
        }
    });
}

option = {
    backgroundColor: '#000',
    toolbox: {
        show: true,
        left: 'right',
        right: 20,
        top: 'bottom',
        bottom: 20,
    },
    color: legendColor,
    legend: {
        show: true,
        data: legend,
        textStyle: {
            color: '#fff',
            fontSize: 10,
        },
        // inactiveColor: "#fff",
        icon: 'circle',
        type: 'scroll',
        orient: 'vertical',
        left: 'right',
        right: 20,
        top: 20,
        bottom: 80,
        // itemWidth: 12,
        // itemHeight: 12,
        pageIconColor: '#00f6ff',
        pageIconInactiveColor: '#fff',
        pageIconSize: 12,
        pageTextStyle: {
            color: '#fff',
            fontSize: 12,
        },
    },
    selectedMode: 'false',
    bottom: 20,
    left: 0,
    right: 0,
    top: 0,
    animationDuration: 1500,
    animationEasingUpdate: 'quinticInOut',
    series: [
        {
            name: '知识图谱',
            type: 'graph',
            hoverAnimation: true,
            layout: 'force',
            force: {
                repulsion: 300,
                edgeLength: 100,
            },
            nodeScaleRatio: 0.6,
            draggable: true,
            roam: true,
            symbol: 'circle',
            data: list,
            links: links,
            categories: categories,
            focusNodeAdjacency: true,
            scaleLimit: {
                //所属组件的z分层，z值小的图形会被z值大的图形覆盖
                min: 0.5, //最小的缩放值
                max: 9, //最大的缩放值
            },
            edgeSymbol: ['circle', 'arrow'],
            edgeSymbolSize: [4, 8],
            label: {
                normal: {
                    show: true,
                    position: 'right',
                    color: '#fff',
                    distance: 5,
                    fontSize: 10,
                },
            },
            lineStyle: {
                normal: {
                    width: 1.5,
                    curveness: 0,
                    type: 'solid',
                },
            },
        },
    ],
};
